/*
 Template Name: Zinzer - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesdesign
 Website: www.themesdesign.in
 File: Alertify init js
 */

"use strict";

(function() {

	function $(selector) {
		return document.querySelector(selector);
	}

	function reset(ev) {
		ev.preventDefault();
		alertify.reset();
	}

	function logDemo(selector) {
		(ga || function() {})("send", "event", "button", "click", "demo", selector);
	}

	function demo(selector, cb) {
		var el = $(selector);
		if(el) {
			el.addEventListener("click", function(ev) {
				ev.preventDefault();
				logDemo(selector);
				cb();
			});
		}
	}

	var ga = ga || function() {};

	demo("#alertify-confirm", function(ev) {
		alertify.confirm("确认取消报名?", function(ev) {
			ev.preventDefault();
			alertify.success("成功取消报名！");
		}, function(ev) {
			ev.preventDefault();
		});
	});

	demo("#alertify-success1", function(ev) {
		alertify.success("报名成功！");
	});
	demo("#alertify-success2", function(ev) {
		alertify.success("报名成功！");
	});

	demo("#alertify-log-position", function() {
		alertify.delay(1000); // This is just to make the demo go faster.
		alertify.log("Default bottom left position");
		setTimeout(function() {
			alertify.logPosition("top left");
			alertify.log("top left");
		}, 1500);
		setTimeout(function() {
			alertify.logPosition("top right");
			alertify.log("top right");
		}, 3000);
		setTimeout(function() {
			alertify.logPosition("bottom right");
			alertify.log("bottom right");
		}, 4500);
		setTimeout(function() {
			alertify.reset(); // Puts the message back to default position.
			alertify.log("Back to default");
		}, 6000);
	});

})();