package edu.njust.servlet;

import edu.njust.entity.StudentExperiment;
import edu.njust.entity.User;
import edu.njust.service.ExperimentService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class StudentSignUpServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        User user=(User)req.getSession().getAttribute("user");
        String stuId=user.getUserId();
        String opt=req.getParameter("opt");
        String expName=req.getParameter("expName");
        String expTeacherName=req.getParameter("expTeacherName");
        String expTerm=req.getParameter("expTerm");
        ExperimentService experimentService=new ExperimentService();
        StudentExperiment studentExperiment=new StudentExperiment(stuId,expName,expTerm,expTeacherName);
        if(opt.equals("signUp")){
            experimentService.chooseExp(studentExperiment);
        }
        if(opt.equals("signUpCancel")){
            experimentService.deleteStudentExperiment(studentExperiment);
        }
        req.getRequestDispatcher("/JSP/s/chooseExp.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
